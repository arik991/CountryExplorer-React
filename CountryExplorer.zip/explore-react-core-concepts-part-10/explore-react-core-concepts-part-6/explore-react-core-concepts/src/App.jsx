import './App.css'
import Countries from './Countries';

function App() {

  return (
    <div>

      <Countries></Countries>





    </div>


  )
}

export default App
