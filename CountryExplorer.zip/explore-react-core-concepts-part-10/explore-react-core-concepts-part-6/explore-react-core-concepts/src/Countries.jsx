import React, { useEffect, useState } from 'react';
import Country from './Country';
import './App.css'



const Countries = () => {


     const [countries, setCountries] = useState([]);
     const [visitedCountries, setVisitedCountries] = useState([]);



     useEffect(() => {



          fetch("https://restcountries.com/v3.1/all")
               .then(res => res.json())
               // .then(Data => console.log(Data))
               .then(Data => setCountries(Data))

          console.log(countries);



     }, [])




     const handleVisitedCountry = country => {



          // console.log("Add this to your visited country!")
          console.log(country)

          const newVisitedcountries = [...visitedCountries, country];
          setVisitedCountries(newVisitedcountries);


     }



     return (



          <div>

               <h2>Countries Length: {countries.length}</h2>



               <div>

                    <h5>Visited Countries: {visitedCountries.length}</h5>


                    <ol>
                         {
                              visitedCountries.map(country => <li>
                                   {country.name.common} </li>)

                         }
                    </ol>

               </div>

               <div className='country-container'>




                    {

                         countries.map(country => <Country country={country} handleVisitedCountry={handleVisitedCountry} key={country.cca3} ></Country>)

                    }


               </div>



          </div>


     );
};

export default Countries;