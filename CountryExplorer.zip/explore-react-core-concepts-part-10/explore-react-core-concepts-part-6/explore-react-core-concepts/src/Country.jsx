import React, { useState } from 'react';


const Country = ({ country, handleVisitedCountry }) => {

     const { name, population, capital, flags, cca3 } = country;

     const [visited, setVisited] = useState(false);

     const handleVisited = () => {


          // setVisited(true);

          setVisited(!visited)

     }


     const passWithparams = () => handleVisitedCountry(country);



     // console.log(handleVisitedCountry);


     return (


          // <div className='country'>

          <div className={`country ${visited && 'visited'}`}>

               {/* M-2) <div className={`country ${visited? 'visited : non-visited'}`}> */}


               {/* M-1) <h3 style={{ color: visited ? 'orange' : 'green' }}>Name : {name.common}</h3> */}


               <h3>Capital : {capital}</h3>
               <h3>Population : {population} </h3>
               <h4><small>Code:{cca3}</small></h4>


               {/* <button onClick={handleVisited}>Visited</button> */}
               {/* {visited && */}

               {/* <p>I have visited this country!</p>} */}


               <button onClick={handleVisited}>{visited ?
                    'Visited' : 'Going'}</button>

               <br />

               <br />
               {/* <button onClick={handleVisitedCountry}>Mark Visited</button> */}

               <button onClick={() => handleVisitedCountry(country)}>Mark Visited</button>

               {visited ? <p> I have visited this country!</p> : <p>I want to visit </p>}






               {/* <h3>Name : {name.common}</h3> */}

               <img src={flags.png} />

          </div >
     );
};

export default Country;